#!/bin/bash

MAIN_CLASS="ar.edu.itba.cripto.Main"

java -cp 'lib/jars/*' $MAIN_CLASS "$@"